"""
打卡工具函数 - 校园打卡平台
"""
import math
import requests
from django.conf import settings


def calculate_distance(lat1, lng1, lat2, lng2):
    """
    使用Haversine公式计算两点间距离（米）
    """
    R = 6371000  # 地球半径（米）
    
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    delta_lat = math.radians(lat2 - lat1)
    delta_lng = math.radians(lng2 - lng1)
    
    a = (math.sin(delta_lat / 2) ** 2 +
         math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lng / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c


def verify_location(user_lat, user_lng, activity_lat, activity_lng, radius=500):
    """
    验证用户位置是否在活动允许范围内
    
    Args:
        user_lat: 用户纬度
        user_lng: 用户经度
        activity_lat: 活动纬度
        activity_lng: 活动经度
        radius: 允许范围（米）
    
    Returns:
        (bool, str): (是否通过, 提示信息)
    """
    if not all([user_lat, user_lng, activity_lat, activity_lng]):
        return False, "位置信息不完整"
    
    distance = calculate_distance(
        float(user_lat), float(user_lng),
        float(activity_lat), float(activity_lng)
    )
    
    if distance <= radius:
        return True, f"距离活动位置{distance:.0f}米，验证通过"
    else:
        return False, f"距离活动位置{distance:.0f}米，超出允许范围{radius}米"


def get_address_from_coordinates(lat, lng):
    """
    使用高德地图API将坐标转换为地址
    """
    if not settings.AMAP_KEY:
        return f"{lat},{lng}"
    
    url = "https://restapi.amap.com/v3/geocode/regeo"
    params = {
        'key': settings.AMAP_KEY,
        'location': f"{lng},{lat}",
        'extensions': 'base',
    }
    
    try:
        response = requests.get(url, params=params, timeout=5)
        data = response.json()
        if data.get('status') == '1':
            return data['regeocode']['formatted_address']
    except Exception as e:
        pass
    
    return f"{lat},{lng}"
