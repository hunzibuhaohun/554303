from django.apps import AppConfig


class CheckinsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.checkins'
    verbose_name = '打卡管理'
