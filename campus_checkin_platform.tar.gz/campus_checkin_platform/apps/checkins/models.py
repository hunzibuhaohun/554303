"""
打卡模型 - 校园打卡平台
"""
from django.db import models
from django.conf import settings


class CheckIn(models.Model):
    """打卡记录模型"""
    STATUS_CHOICES = [
        ('pending', '待审核'),
        ('approved', '已通过'),
        ('rejected', '已拒绝'),
    ]
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='checkins'
    )
    activity = models.ForeignKey(
        'activities.Activity',
        on_delete=models.CASCADE,
        related_name='checkins'
    )
    registration = models.OneToOneField(
        'activities.ActivityRegistration',
        on_delete=models.CASCADE,
        related_name='checkin'
    )
    
    # 打卡信息
    remark = models.TextField('打卡备注', blank=True)
    
    # 定位信息
    location_name = models.CharField('位置名称', max_length=200, blank=True)
    latitude = models.DecimalField('纬度', max_digits=10, decimal_places=7)
    longitude = models.DecimalField('经度', max_digits=10, decimal_places=7)
    accuracy = models.FloatField('精度(米)', null=True, blank=True)
    
    # 审核状态
    status = models.CharField(
        '状态',
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='reviewed_checkins'
    )
    review_note = models.TextField('审核备注', blank=True)
    
    # 积分
    points_earned = models.PositiveIntegerField('获得积分', default=0)
    
    # 时间戳
    created_at = models.DateTimeField('打卡时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)
    
    class Meta:
        verbose_name = '打卡记录'
        verbose_name_plural = '打卡记录'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'created_at']),
            models.Index(fields=['activity', 'status']),
        ]
    
    def __str__(self):
        return f"{self.user.username} - {self.activity.title} - {self.created_at.strftime('%Y-%m-%d')}"
    
    def approve(self, reviewer=None, note=''):
        """通过审核"""
        self.status = 'approved'
        self.reviewed_by = reviewer
        self.review_note = note
        self.points_earned = self.activity.points
        
        # 更新用户积分
        self.user.points += self.points_earned
        self.user.total_checkins += 1
        self.user.save(update_fields=['points', 'total_checkins'])
        
        # 更新报名状态
        self.registration.status = 'completed'
        self.registration.save(update_fields=['status'])
        
        self.save()
    
    def reject(self, reviewer=None, note=''):
        """拒绝审核"""
        self.status = 'rejected'
        self.reviewed_by = reviewer
        self.review_note = note
        self.save()


class CheckInPhoto(models.Model):
    """打卡照片"""
    checkin = models.ForeignKey(
        CheckIn,
        on_delete=models.CASCADE,
        related_name='photos'
    )
    image = models.ImageField('照片', upload_to='checkins/%Y/%m/%d/')
    uploaded_at = models.DateTimeField('上传时间', auto_now_add=True)
    
    class Meta:
        verbose_name = '打卡照片'
        verbose_name_plural = '打卡照片'
