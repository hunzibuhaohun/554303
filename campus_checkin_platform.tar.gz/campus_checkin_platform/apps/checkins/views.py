"""
打卡视图 - 校园打卡平台
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.core.paginator import Paginator

from .models import CheckIn, CheckInPhoto
from .forms import CheckInForm
from .utils import verify_location
from apps.activities.models import Activity, ActivityRegistration


@login_required
def checkin_view(request):
    """打卡页面视图"""
    # 获取用户已报名且未打卡的活动
    registrations = ActivityRegistration.objects.filter(
        user=request.user,
        status='registered'
    ).select_related('activity')
    
    if request.method == 'POST':
        form = CheckInForm(user=request.user, data=request.POST, files=request.FILES)
        
        if form.is_valid():
            activity_id = form.cleaned_data['activity']
            activity = get_object_or_404(Activity, id=activity_id)
            
            # 获取定位信息
            latitude = form.cleaned_data['latitude']
            longitude = form.cleaned_data['longitude']
            accuracy = form.cleaned_data['accuracy']
            
            # 验证位置
            if activity.location_lat and activity.location_lng:
                is_valid, message = verify_location(
                    latitude, longitude,
                    activity.location_lat, activity.location_lng,
                    activity.checkin_radius
                )
                if not is_valid:
                    messages.error(request, f'位置验证失败：{message}')
                    return render(request, 'checkins/checkin.html', {
                        'form': form,
                        'registrations': registrations
                    })
            
            # 获取报名记录
            registration = ActivityRegistration.objects.get(
                user=request.user,
                activity=activity
            )
            
            # 创建打卡记录
            checkin = form.save(commit=False)
            checkin.user = request.user
            checkin.activity = activity
            checkin.registration = registration
            checkin.save()
            
            # 保存照片
            photos = request.FILES.getlist('photos')
            for photo in photos:
                CheckInPhoto.objects.create(checkin=checkin, image=photo)
            
            # 自动通过审核（简化流程）
            checkin.approve()
            
            messages.success(request, f'打卡成功！获得{checkin.points_earned}积分')
            return redirect('checkins:history')
        else:
            messages.error(request, '打卡失败，请检查填写信息')
    else:
        form = CheckInForm(user=request.user)
    
    return render(request, 'checkins/checkin.html', {
        'form': form,
        'registrations': registrations
    })


@login_required
def checkin_history(request):
    """打卡历史"""
    checkins = CheckIn.objects.filter(
        user=request.user
    ).select_related('activity').order_by('-created_at')
    
    # 分页
    paginator = Paginator(checkins, 10)
    page = request.GET.get('page')
    checkins = paginator.get_page(page)
    
    return render(request, 'checkins/history.html', {
        'checkins': checkins
    })


@login_required
def checkin_detail(request, pk):
    """打卡详情"""
    checkin = get_object_or_404(
        CheckIn.objects.select_related('activity', 'user'),
        pk=pk,
        user=request.user
    )
    
    return render(request, 'checkins/detail.html', {
        'checkin': checkin
    })


@login_required
def verify_location_api(request):
    """验证位置API"""
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': '请求方式错误'})
    
    try:
        activity_id = request.POST.get('activity_id')
        latitude = float(request.POST.get('latitude'))
        longitude = float(request.POST.get('longitude'))
    except (ValueError, TypeError):
        return JsonResponse({'success': False, 'message': '参数错误'})
    
    activity = get_object_or_404(Activity, id=activity_id)
    
    # 如果活动没有设置位置，直接通过
    if not activity.location_lat or not activity.location_lng:
        return JsonResponse({
            'success': True,
            'message': '活动未设置位置限制',
            'distance': 0
        })
    
    is_valid, message = verify_location(
        latitude, longitude,
        activity.location_lat, activity.location_lng,
        activity.checkin_radius
    )
    
    return JsonResponse({
        'success': is_valid,
        'message': message
    })


# Admin视图 - 审核打卡
@login_required
def pending_checkins(request):
    """待审核打卡列表"""
    if not request.user.is_staff:
        messages.error(request, '您没有权限访问此页面')
        return redirect('index')
    
    checkins = CheckIn.objects.filter(
        status='pending'
    ).select_related('activity', 'user').order_by('-created_at')
    
    return render(request, 'checkins/pending.html', {
        'checkins': checkins
    })


@login_required
@require_POST
def approve_checkin(request, pk):
    """通过打卡"""
    if not request.user.is_staff:
        return JsonResponse({'success': False, 'message': '无权限'})
    
    checkin = get_object_or_404(CheckIn, pk=pk)
    note = request.POST.get('note', '')
    
    checkin.approve(reviewer=request.user, note=note)
    
    return JsonResponse({
        'success': True,
        'message': '审核通过',
        'points': checkin.points_earned
    })


@login_required
@require_POST
def reject_checkin(request, pk):
    """拒绝打卡"""
    if not request.user.is_staff:
        return JsonResponse({'success': False, 'message': '无权限'})
    
    checkin = get_object_or_404(CheckIn, pk=pk)
    note = request.POST.get('note', '')
    
    checkin.reject(reviewer=request.user, note=note)
    
    return JsonResponse({
        'success': True,
        'message': '审核已拒绝'
    })
