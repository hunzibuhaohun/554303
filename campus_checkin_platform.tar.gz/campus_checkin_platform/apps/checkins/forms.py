"""
打卡表单 - 校园打卡平台
"""
from django import forms
from .models import CheckIn


class CheckInForm(forms.ModelForm):
    """打卡表单"""
    photos = forms.FileField(
        label='打卡照片',
        required=True,
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': 'image/*',
            'multiple': True
        })
    )
    
    class Meta:
        model = CheckIn
        fields = ['activity', 'remark', 'latitude', 'longitude', 'accuracy', 'location_name']
        widgets = {
            'activity': forms.Select(attrs={'class': 'form-control'}),
            'remark': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '添加打卡备注（可选）'
            }),
            'latitude': forms.HiddenInput(),
            'longitude': forms.HiddenInput(),
            'accuracy': forms.HiddenInput(),
            'location_name': forms.HiddenInput(),
        }
    
    def __init__(self, user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            # 只显示用户已报名且未打卡的活动
            from apps.activities.models import ActivityRegistration
            registered_activities = ActivityRegistration.objects.filter(
                user=user,
                status='registered'
            ).select_related('activity')
            self.fields['activity'].queryset = ActivityRegistration.objects.filter(
                user=user,
                status='registered'
            ).values_list('activity', flat=True)
            self.fields['activity'].choices = [
                (reg.activity.id, f"{reg.activity.title} ({reg.activity.start_time.strftime('%m月%d日')})")
                for reg in registered_activities
            ]
