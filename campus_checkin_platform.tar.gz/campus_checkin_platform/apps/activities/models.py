"""
活动模型 - 校园打卡平台
"""
from django.db import models
from django.conf import settings
from django.utils import timezone


class Category(models.Model):
    """活动分类"""
    name = models.CharField('分类名称', max_length=50, unique=True)
    icon = models.CharField('图标类名', max_length=50, default='fas fa-tag')
    color = models.CharField('颜色', max_length=20, default='#3B82F6')
    description = models.TextField('描述', blank=True)
    sort_order = models.PositiveIntegerField('排序', default=0)
    
    class Meta:
        verbose_name = '活动分类'
        verbose_name_plural = '活动分类'
        ordering = ['sort_order']
    
    def __str__(self):
        return self.name


class Activity(models.Model):
    """活动模型"""
    STATUS_CHOICES = [
        ('draft', '草稿'),
        ('upcoming', '即将开始'),
        ('ongoing', '进行中'),
        ('ended', '已结束'),
        ('cancelled', '已取消'),
    ]
    
    # 基本信息
    title = models.CharField('活动标题', max_length=100)
    description = models.TextField('活动描述')
    cover_image = models.ImageField(
        '封面图片',
        upload_to='activities/covers/%Y/%m/',
        default='activities/default.jpg'
    )
    
    # 分类与创建者
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name='分类'
    )
    creator = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='created_activities',
        verbose_name='创建者'
    )
    
    # 时间信息
    start_time = models.DateTimeField('开始时间')
    end_time = models.DateTimeField('结束时间')
    registration_deadline = models.DateTimeField('报名截止时间', null=True, blank=True)
    
    # 地点信息
    location = models.CharField('活动地点', max_length=200)
    location_lat = models.DecimalField('纬度', max_digits=10, decimal_places=7, null=True, blank=True)
    location_lng = models.DecimalField('经度', max_digits=10, decimal_places=7, null=True, blank=True)
    
    # 参与限制
    max_participants = models.PositiveIntegerField('最大参与人数', default=50)
    min_participants = models.PositiveIntegerField('最小参与人数', default=1)
    
    # 积分与状态
    points = models.PositiveIntegerField('积分奖励', default=10)
    status = models.CharField(
        '状态',
        max_length=20,
        choices=STATUS_CHOICES,
        default='upcoming'
    )
    
    # 额外要求
    requirements = models.TextField('参与要求', blank=True)
    allow_checkin_before_start = models.BooleanField('允许开始前打卡', default=False)
    checkin_radius = models.PositiveIntegerField('打卡范围(米)', default=500)
    
    # 统计字段
    view_count = models.PositiveIntegerField('浏览次数', default=0)
    
    # 时间戳
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)
    
    class Meta:
        verbose_name = '活动'
        verbose_name_plural = '活动'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status', 'start_time']),
            models.Index(fields=['category']),
            models.Index(fields=['creator']),
        ]
    
    def __str__(self):
        return self.title
    
    @property
    def is_hot(self):
        """是否热门活动"""
        return self.participants.count() > self.max_participants * 0.8
    
    @property
    def registration_percentage(self):
        """报名进度百分比"""
        if self.max_participants == 0:
            return 0
        return int(self.participants.count() / self.max_participants * 100)
    
    @property
    def is_full(self):
        """是否已满员"""
        return self.participants.count() >= self.max_participants
    
    def update_status(self):
        """更新活动状态"""
        now = timezone.now()
        if self.status == 'cancelled':
            return
        if now < self.start_time:
            self.status = 'upcoming'
        elif self.start_time <= now <= self.end_time:
            self.status = 'ongoing'
        else:
            self.status = 'ended'
        self.save(update_fields=['status'])


class ActivityRegistration(models.Model):
    """活动报名记录"""
    STATUS_CHOICES = [
        ('registered', '已报名'),
        ('checked_in', '已打卡'),
        ('completed', '已完成'),
        ('cancelled', '已取消'),
    ]
    
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='activity_registrations'
    )
    activity = models.ForeignKey(
        Activity,
        on_delete=models.CASCADE,
        related_name='participants'
    )
    status = models.CharField(
        '状态',
        max_length=20,
        choices=STATUS_CHOICES,
        default='registered'
    )
    registered_at = models.DateTimeField('报名时间', auto_now_add=True)
    checked_in_at = models.DateTimeField('打卡时间', null=True, blank=True)
    
    class Meta:
        unique_together = ['user', 'activity']
        verbose_name = '活动报名'
        verbose_name_plural = '活动报名'
    
    def __str__(self):
        return f"{self.user.username} - {self.activity.title}"


class ActivityComment(models.Model):
    """活动评论"""
    activity = models.ForeignKey(
        Activity,
        on_delete=models.CASCADE,
        related_name='comments'
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE
    )
    content = models.TextField('评论内容')
    parent = models.ForeignKey(
        'self',
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        related_name='replies'
    )
    likes = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name='liked_comments',
        blank=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = '活动评论'
        verbose_name_plural = '活动评论'
