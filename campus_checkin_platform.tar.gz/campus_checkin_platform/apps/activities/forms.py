"""
活动表单 - 校园打卡平台
"""
from django import forms
from .models import Activity, ActivityComment


class ActivityForm(forms.ModelForm):
    """活动创建/编辑表单"""
    class Meta:
        model = Activity
        fields = ['title', 'description', 'cover_image', 'category', 
                  'start_time', 'end_time', 'registration_deadline',
                  'location', 'location_lat', 'location_lng',
                  'max_participants', 'min_participants', 'points',
                  'requirements', 'allow_checkin_before_start', 'checkin_radius']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入活动标题'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': '请详细描述活动内容'
            }),
            'category': forms.Select(attrs={'class': 'form-control'}),
            'start_time': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'end_time': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'registration_deadline': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local'
            }),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '请输入活动地点'
            }),
            'location_lat': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '纬度（可选）',
                'step': 'any'
            }),
            'location_lng': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '经度（可选）',
                'step': 'any'
            }),
            'max_participants': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1
            }),
            'min_participants': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1
            }),
            'points': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0
            }),
            'requirements': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '参与要求（可选）'
            }),
            'allow_checkin_before_start': forms.CheckboxInput(attrs={
                'class': 'form-check-input'
            }),
            'checkin_radius': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'placeholder': '允许打卡的范围（米）'
            }),
        }


class ActivityCommentForm(forms.ModelForm):
    """活动评论表单"""
    class Meta:
        model = ActivityComment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': '发表评论...'
            }),
        }
