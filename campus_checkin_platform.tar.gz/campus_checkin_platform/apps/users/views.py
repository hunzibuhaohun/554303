"""
用户视图 - 校园打卡平台
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.http import JsonResponse
from django.views.decorators.http import require_POST

from .models import User, FollowRelation
from .forms import UserRegistrationForm, UserLoginForm, UserProfileForm, UserSettingsForm


def register_view(request):
    """用户注册视图"""
    if request.user.is_authenticated:
        return redirect('index')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, '注册成功！欢迎加入校园打卡平台！')
            return redirect('index')
        else:
            messages.error(request, '注册失败，请检查填写信息。')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'users/register.html', {'form': form})


def login_view(request):
    """用户登录视图"""
    if request.user.is_authenticated:
        return redirect('index')
    
    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            
            # 尝试用学号登录
            if user is None:
                try:
                    user_by_student_id = User.objects.get(student_id=username)
                    user = authenticate(request, username=user_by_student_id.username, password=password)
                except User.DoesNotExist:
                    pass
            
            if user is not None:
                login(request, user)
                messages.success(request, f'欢迎回来，{user.get_full_name()}！')
                next_url = request.GET.get('next', 'index')
                return redirect(next_url)
            else:
                messages.error(request, '用户名或密码错误。')
        else:
            messages.error(request, '登录失败，请检查填写信息。')
    else:
        form = UserLoginForm()
    
    return render(request, 'users/login.html', {'form': form})


def logout_view(request):
    """用户退出视图"""
    logout(request)
    messages.success(request, '已成功退出登录。')
    return redirect('index')


@login_required
def profile_view(request):
    """个人中心视图"""
    user = request.user
    
    # 获取统计数据
    context = {
        'profile_user': user,
        'streak_days': user.streak_days,
        'followers_count': user.followers.count(),
        'following_count': user.following.count(),
        'achievements': user.achievements.all()[:6],
        'recent_checkins': user.checkins.select_related('activity').order_by('-created_at')[:5],
        'created_activities': user.created_activities.order_by('-created_at')[:5],
    }
    return render(request, 'users/profile.html', context)


@login_required
def profile_detail_view(request, user_id):
    """他人资料视图"""
    profile_user = get_object_or_404(User, id=user_id)
    
    # 检查是否已关注
    is_following = FollowRelation.objects.filter(
        follower=request.user,
        following=profile_user
    ).exists()
    
    context = {
        'profile_user': profile_user,
        'is_following': is_following,
        'streak_days': profile_user.streak_days,
        'followers_count': profile_user.followers.count(),
        'following_count': profile_user.following.count(),
        'achievements': profile_user.achievements.all()[:6],
        'recent_checkins': profile_user.checkins.select_related('activity').order_by('-created_at')[:5],
    }
    return render(request, 'users/profile_detail.html', context)


@login_required
def profile_edit_view(request):
    """编辑个人资料视图"""
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, '个人资料更新成功！')
            return redirect('users:profile')
        else:
            messages.error(request, '更新失败，请检查填写信息。')
    else:
        form = UserProfileForm(instance=request.user)
    
    return render(request, 'users/profile_edit.html', {'form': form})


@login_required
def settings_view(request):
    """用户设置视图"""
    if request.method == 'POST':
        form = UserSettingsForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, '设置保存成功！')
            return redirect('users:settings')
        else:
            messages.error(request, '保存失败，请检查填写信息。')
    else:
        form = UserSettingsForm(instance=request.user)
    
    return render(request, 'users/settings.html', {'form': form})


@login_required
@require_POST
def follow_user(request, user_id):
    """关注用户"""
    target_user = get_object_or_404(User, id=user_id)
    
    if target_user == request.user:
        return JsonResponse({'success': False, 'message': '不能关注自己'})
    
    follow_relation, created = FollowRelation.objects.get_or_create(
        follower=request.user,
        following=target_user
    )
    
    if created:
        return JsonResponse({
            'success': True, 
            'message': '关注成功',
            'followers_count': target_user.followers.count()
        })
    else:
        return JsonResponse({'success': False, 'message': '已经关注了'})


@login_required
@require_POST
def unfollow_user(request, user_id):
    """取消关注用户"""
    target_user = get_object_or_404(User, id=user_id)
    
    deleted, _ = FollowRelation.objects.filter(
        follower=request.user,
        following=target_user
    ).delete()
    
    if deleted:
        return JsonResponse({
            'success': True, 
            'message': '取消关注成功',
            'followers_count': target_user.followers.count()
        })
    else:
        return JsonResponse({'success': False, 'message': '未关注该用户'})


@login_required
def followers_list(request):
    """粉丝列表"""
    followers = request.user.followers.all()
    return render(request, 'users/followers.html', {'users': followers, 'title': '我的粉丝'})


@login_required
def following_list(request):
    """关注列表"""
    following = request.user.following.all()
    return render(request, 'users/following.html', {'users': following, 'title': '我的关注'})
