"""
用户模型 - 校园打卡平台
"""
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import RegexValidator


class User(AbstractUser):
    """自定义用户模型"""
    GENDER_CHOICES = [
        ('male', '男'),
        ('female', '女'),
        ('secret', '保密'),
    ]
    
    ROLE_CHOICES = [
        ('student', '学生'),
        ('teacher', '教师'),
        ('admin', '管理员'),
    ]
    
    # 基本信息
    student_id = models.CharField(
        '学号',
        max_length=20,
        unique=True,
        null=True,
        blank=True
    )
    real_name = models.CharField('真实姓名', max_length=50, default='')
    gender = models.CharField(
        '性别',
        max_length=10,
        choices=GENDER_CHOICES,
        default='secret'
    )
    phone = models.CharField(
        '手机号',
        max_length=11,
        validators=[RegexValidator(r'^1[3-9]\d{9}$', '请输入有效的手机号')],
        blank=True
    )
    
    # 学校信息
    department = models.CharField('院系', max_length=100, blank=True)
    major = models.CharField('专业', max_length=100, blank=True)
    grade = models.CharField('年级', max_length=20, blank=True)
    
    # 角色与状态
    role = models.CharField(
        '角色',
        max_length=20,
        choices=ROLE_CHOICES,
        default='student'
    )
    is_verified = models.BooleanField('是否认证', default=False)
    
    # 个人资料
    avatar = models.ImageField(
        '头像',
        upload_to='avatars/%Y/%m/',
        default='avatars/default.png',
        blank=True
    )
    bio = models.TextField('个人简介', max_length=500, blank=True)
    
    # 积分系统
    points = models.PositiveIntegerField('当前积分', default=0)
    total_checkins = models.PositiveIntegerField('累计打卡次数', default=0)
    
    # 社交数据
    followers = models.ManyToManyField(
        'self',
        symmetrical=False,
        related_name='following',
        through='FollowRelation',
        blank=True
    )
    
    # 时间戳
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)
    
    class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['student_id']),
            models.Index(fields=['department']),
        ]
    
    def __str__(self):
        return f"{self.username} ({self.real_name or '未实名'})"
    
    def get_full_name(self):
        return self.real_name or self.username
    
    @property
    def streak_days(self):
        """计算连续打卡天数"""
        from django.utils import timezone
        from apps.checkins.models import CheckIn
        
        checkins = CheckIn.objects.filter(
            user=self,
            status='approved'
        ).order_by('-created_at')
        
        if not checkins.exists():
            return 0
        
        streak = 0
        today = timezone.now().date()
        check_dates = set(c.created_at.date() for c in checkins)
        
        while today in check_dates:
            streak += 1
            today -= timezone.timedelta(days=1)
        
        return streak


class FollowRelation(models.Model):
    """关注关系模型"""
    follower = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='follow_relations_as_follower'
    )
    following = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='follow_relations_as_following'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['follower', 'following']
        verbose_name = '关注关系'
        verbose_name_plural = '关注关系'


class UserAchievement(models.Model):
    """用户成就模型"""
    ACHIEVEMENT_TYPES = [
        ('first_checkin', '首次打卡'),
        ('streak_7', '连续7天'),
        ('streak_30', '连续30天'),
        ('points_100', '积分破百'),
        ('points_1000', '积分破千'),
        ('creator', '活动创建者'),
        ('popular', '人气王'),
    ]
    
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='achievements'
    )
    achievement_type = models.CharField(
        '成就类型',
        max_length=20,
        choices=ACHIEVEMENT_TYPES
    )
    name = models.CharField('成就名称', max_length=50)
    description = models.TextField('成就描述')
    icon = models.CharField('图标类名', max_length=50, default='fas fa-medal')
    level = models.CharField(
        '等级',
        max_length=10,
        choices=[('bronze', '铜'), ('silver', '银'), ('gold', '金')],
        default='bronze'
    )
    earned_at = models.DateTimeField('获得时间', auto_now_add=True)
    
    class Meta:
        verbose_name = '用户成就'
        verbose_name_plural = '用户成就'
        unique_together = ['user', 'achievement_type']
