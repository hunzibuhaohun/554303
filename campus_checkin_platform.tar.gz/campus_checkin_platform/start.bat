@echo off
chcp 65001 >nul
echo 🚀 启动校园打卡平台...

:: 检查虚拟环境
if not exist "venv" (
    echo 📦 创建虚拟环境...
    python -m venv venv
)

:: 激活虚拟环境
call venv\Scripts\activate.bat

:: 安装依赖
echo 📥 安装依赖...
pip install -r requirements.txt

:: 数据库迁移
echo 🗄️ 执行数据库迁移...
python manage.py migrate

:: 收集静态文件
echo 📁 收集静态文件...
python manage.py collectstatic --noinput

:: 启动开发服务器
echo 🌐 启动服务器...
echo 访问地址: http://127.0.0.1:8000/
echo 管理后台: http://127.0.0.1:8000/admin/ (admin / admin123)
python manage.py runserver

pause
